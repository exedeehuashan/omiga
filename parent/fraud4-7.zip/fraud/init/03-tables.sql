CREATE TABLE IF NOT EXISTS fraud.accounts (
    account_id BIGINT,
    customer_id BIGINT NOT NULL,
    account_type TEXT,
    status TEXT,
    opened_at TIMESTAMP DEFAULT NOW(),
    PRIMARY KEY (account_id, customer_id)
);

CREATE TABLE IF NOT EXISTS fraud.transactions (
    transaction_id BIGINT,
    customer_id BIGINT NOT NULL,
    account_id BIGINT NOT NULL,
    merchant_id BIGINT,
    amount NUMERIC(12,2),
    currency TEXT,
    transaction_time TIMESTAMP NOT NULL,
    location TEXT,
    channel TEXT,
    device_id TEXT,
    ip_address TEXT,
    fraud_score NUMERIC(5,2),
    is_flagged BOOLEAN DEFAULT FALSE,
    status TEXT,
    PRIMARY KEY (transaction_id, customer_id)
);

CREATE INDEX IF NOT EXISTS idx_accounts_customer
ON fraud.accounts (customer_id);

CREATE INDEX IF NOT EXISTS idx_transactions_time
ON fraud.transactions (transaction_time);

CREATE INDEX IF NOT EXISTS idx_transactions_flagged
ON fraud.transactions (is_flagged);

CREATE INDEX IF NOT EXISTS idx_transactions_score
ON fraud.transactions (fraud_score);

CREATE INDEX IF NOT EXISTS idx_transactions_account_customer
ON fraud.transactions (account_id, customer_id);

CREATE INDEX IF NOT EXISTS idx_transactions_time_score
ON fraud.transactions (transaction_time, fraud_score);