CREATE EXTENSION IF NOT EXISTS citus;

SELECT create_reference_table('fraud.customers');
SELECT create_reference_table('fraud.merchants');

SELECT create_distributed_table('fraud.accounts', 'customer_id');
SELECT create_distributed_table('fraud.transactions', 'customer_id');