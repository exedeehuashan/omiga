TRUNCATE TABLE fraud.transactions RESTART IDENTITY CASCADE;
TRUNCATE TABLE fraud.accounts RESTART IDENTITY CASCADE;
TRUNCATE TABLE fraud.merchants RESTART IDENTITY CASCADE;
TRUNCATE TABLE fraud.customers RESTART IDENTITY CASCADE;

INSERT INTO fraud.customers (
    customer_id,
    full_name,
    email,
    phone,
    region,
    risk_level,
    created_at
)
SELECT
    gs,
    'Customer_' || gs,
    'customer_' || gs || '@example.com',
    '020' || lpad((gs % 10000000)::text, 7, '0'),
    (ARRAY['Auckland', 'Wellington', 'Christchurch', 'Hamilton', 'Dunedin'])[1 + floor(random() * 5)::int],
    (ARRAY['LOW', 'MEDIUM', 'HIGH'])[1 + floor(random() * 3)::int],
    NOW() - (random() * INTERVAL '365 days')
FROM generate_series(1, GREATEST(10000, :tx_count / 10)) gs;

INSERT INTO fraud.merchants (
    merchant_id,
    merchant_name,
    category,
    country
)
SELECT
    gs,
    'Merchant_' || gs,
    (ARRAY['E-COMMERCE', 'GROCERY', 'FUEL', 'TRAVEL', 'ELECTRONICS'])[1 + floor(random() * 5)::int],
    (ARRAY['NZ', 'AU', 'US', 'SG', 'UK'])[1 + floor(random() * 5)::int]
FROM generate_series(1, 5000) gs;

INSERT INTO fraud.accounts (
    account_id,
    customer_id,
    account_type,
    status,
    opened_at
)
SELECT
    gs,
    ((gs - 1) % GREATEST(10000, :tx_count / 10)) + 1,
    (ARRAY['SAVINGS', 'CHECKING', 'CREDIT'])[1 + floor(random() * 3)::int],
    (ARRAY['ACTIVE', 'SUSPENDED', 'CLOSED'])[1 + floor(random() * 3)::int],
    NOW() - (random() * INTERVAL '365 days')
FROM generate_series(1, GREATEST(20000, :tx_count / 5)) gs;

INSERT INTO fraud.transactions (
    transaction_id,
    customer_id,
    account_id,
    merchant_id,
    amount,
    currency,
    transaction_time,
    location,
    channel,
    device_id,
    ip_address,
    fraud_score,
    is_flagged,
    status
)
SELECT
    gs,
    ((gs - 1) % GREATEST(10000, :tx_count / 10)) + 1,
    ((gs - 1) % GREATEST(20000, :tx_count / 5)) + 1,
    ((gs - 1) % 5000) + 1,
    round((10 + random() * 20000)::numeric, 2),
    'NZD',
    NOW() - (random() * INTERVAL '180 days'),
    (ARRAY['Auckland', 'Wellington', 'Christchurch', 'Hamilton', 'Dunedin'])[1 + floor(random() * 5)::int],
    (ARRAY['WEB', 'MOBILE', 'POS', 'ATM'])[1 + floor(random() * 4)::int],
    'DEV_' || ((random() * 100000)::int),
    '10.' || floor(random()*255)::int || '.' || floor(random()*255)::int || '.' || floor(random()*255)::int,
    round((random() * 100)::numeric, 2),
    CASE WHEN random() > 0.92 THEN TRUE ELSE FALSE END,
    (ARRAY['APPROVED', 'REVIEW', 'DECLINED'])[1 + floor(random() * 3)::int]
FROM generate_series(1, :tx_count) gs;

ANALYZE fraud.customers;
ANALYZE fraud.merchants;
ANALYZE fraud.accounts;
ANALYZE fraud.transactions;