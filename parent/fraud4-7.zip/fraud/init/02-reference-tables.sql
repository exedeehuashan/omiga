CREATE TABLE IF NOT EXISTS fraud.customers (
    customer_id BIGINT PRIMARY KEY,
    full_name TEXT,
    email TEXT,
    phone TEXT,
    region TEXT,
    risk_level TEXT,
    created_at TIMESTAMP DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS fraud.merchants (
    merchant_id BIGINT PRIMARY KEY,
    merchant_name TEXT,
    category TEXT,
    country TEXT
);