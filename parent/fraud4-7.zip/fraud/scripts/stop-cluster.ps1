$ErrorActionPreference = "Stop"

Write-Host "Stopping cluster and removing volumes..."
docker compose down -v

Write-Host "Cluster stopped."