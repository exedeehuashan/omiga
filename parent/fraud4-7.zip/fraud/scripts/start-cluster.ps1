param(
    [Parameter(Mandatory = $true)]
    [ValidateSet("2", "4", "8")]
    [string]$Workers
)

$ErrorActionPreference = "Stop"

function Wait-ForContainerReady {
    param(
        [string]$ContainerName,
        [string]$Database = "citus",
        [int]$MaxRetries = 30,
        [int]$DelaySeconds = 2
    )

    Write-Host "Waiting for $ContainerName to be ready..."

    for ($i = 1; $i -le $MaxRetries; $i++) {
        try {
            if ($Database) {
                docker exec $ContainerName pg_isready -U postgres -d $Database | Out-Null
            }
            else {
                docker exec $ContainerName pg_isready -U postgres | Out-Null
            }

            if ($LASTEXITCODE -eq 0) {
                Write-Host "$ContainerName is ready."
                return
            }
        }
        catch {
        }

        Start-Sleep -Seconds $DelaySeconds
    }

    throw "$ContainerName did not become ready in time."
}

function Register-Worker {
    param(
        [int]$WorkerIndex
    )

    $workerName = "worker$WorkerIndex"

    $checkSql = "SELECT 1 FROM pg_dist_node WHERE nodename = '$workerName' AND nodeport = 5432;"
    $checkResult = docker exec citus-coordinator psql -U postgres -d citus -t -A -c $checkSql

    if ($checkResult -match "^1$") {
        Write-Host "$workerName is already registered. Skipping."
        return
    }

    $addSql = "SELECT * FROM citus_add_node('$workerName', 5432);"
    Write-Host "Registering $workerName ..."
    docker exec citus-coordinator psql -U postgres -d citus -c $addSql
}

Write-Host "Stopping existing cluster and removing volumes..."
docker compose down -v

Write-Host "Starting coordinator..."
docker compose up -d coordinator

Wait-ForContainerReady -ContainerName "citus-coordinator" -Database "citus"

Write-Host "Starting $Workers worker(s)..."
for ($i = 1; $i -le [int]$Workers; $i++) {
    docker compose up -d ("worker" + $i)
}

for ($i = 1; $i -le [int]$Workers; $i++) {
    Wait-ForContainerReady -ContainerName ("citus-worker" + $i) -Database "citus"
}

Write-Host "Ensuring Citus extension exists on coordinator..."
docker exec citus-coordinator psql -U postgres -d citus -c "CREATE EXTENSION IF NOT EXISTS citus;"

for ($i = 1; $i -le [int]$Workers; $i++) {
    Register-Worker -WorkerIndex $i
}

Write-Host ""
Write-Host "Active workers:"
docker exec citus-coordinator psql -U postgres -d citus -c "SELECT * FROM citus_get_active_worker_nodes();"

Write-Host ""
Write-Host "All registered nodes:"
docker exec citus-coordinator psql -U postgres -d citus -c "SELECT nodename, nodeport, noderole, isactive FROM pg_dist_node ORDER BY nodename;"

Write-Host ""
Write-Host "Cluster is ready with $Workers worker(s)."