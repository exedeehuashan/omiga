$ErrorActionPreference = "Stop"

$Container = "citus-coordinator"
$Database = "citus"
$OutputDir = "results\citus"

New-Item -ItemType Directory -Force -Path $OutputDir | Out-Null

$queries = @(
    "q1_recent_high_risk",
    "q2_account_velocity",
    "q3_customer_region_risk",
    "q4_large_amount_flags",
    "q5_join_transactions_accounts",
    "q6_daily_aggregation",
    "q7_window_analysis",
    "q8_customer_account_profile"
)

foreach ($q in $queries) {
    Write-Host "Running $q ..."

    $outputFile = "$OutputDir\$q.txt"

    docker exec $Container psql -U postgres -d $Database `
        -f "/sql/queries/$q.sql" `
        | Out-File -Encoding utf8 $outputFile
}

Write-Host "Benchmark completed (Citus)."