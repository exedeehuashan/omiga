param(
    [Parameter(Mandatory = $true)]
    [ValidateSet("citus", "single")]
    [string]$Target,

    [Parameter(Mandatory = $true)]
    [int]$TxCount
)

$ErrorActionPreference = "Stop"

if ($Target -eq "citus") {
    $Container = "citus-coordinator"
    $Database = "citus"
    $Port = 5432
}
elseif ($Target -eq "single") {
    $Container = "postgres-single"
    $Database = "fraud_single"
    $Port = 5440
}

Write-Host "Loading data into $Target ..."
Write-Host "Target container: $Container"
Write-Host "Transaction count: $TxCount"

Write-Host "`n[1/5] Create schema ..."
Get-Content .\init\01-create-schema.sql | docker exec -i $Container psql -U postgres -d $Database

Write-Host "`n[2/5] Create reference tables ..."
Get-Content .\init\02-reference-tables.sql | docker exec -i $Container psql -U postgres -d $Database

Write-Host "`n[3/5] Create common tables and indexes ..."
Get-Content .\init\03-tables.sql | docker exec -i $Container psql -U postgres -d $Database

if ($Target -eq "citus") {
    Write-Host "`n[4/5] Apply Citus distribution ..."
    Get-Content .\init\04-citus-distribution.sql | docker exec -i $Container psql -U postgres -d $Database
}
else {
    Write-Host "`n[4/5] Skip Citus distribution for single target ..."
}

Write-Host "`n[5/5] Generate data ..."
Get-Content .\init\05-generate-data.sql |
docker exec -i $Container psql -U postgres -d $Database -v tx_count=$TxCount

Write-Host "`nData load complete."

Write-Host "`nRow counts:"
docker exec -i $Container psql -U postgres -d $Database -c @"
SELECT 'customers' AS table_name, COUNT(*) FROM fraud.customers
UNION ALL
SELECT 'merchants', COUNT(*) FROM fraud.merchants
UNION ALL
SELECT 'accounts', COUNT(*) FROM fraud.accounts
UNION ALL
SELECT 'transactions', COUNT(*) FROM fraud.transactions;
"@