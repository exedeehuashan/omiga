EXPLAIN (ANALYZE, BUFFERS, VERBOSE)
SELECT
    c.region,
    a.account_type,
    COUNT(*) AS tx_count,
    COUNT(*) FILTER (WHERE t.is_flagged = TRUE) AS flagged_count,
    AVG(t.amount) AS avg_amount,
    AVG(t.fraud_score) AS avg_score,
    SUM(t.amount) AS total_amount
FROM fraud.transactions t
JOIN fraud.accounts a
  ON t.customer_id = a.customer_id
 AND t.account_id = a.account_id
JOIN fraud.customers c
  ON t.customer_id = c.customer_id
WHERE t.transaction_time >= NOW() - INTERVAL '30 days'
  AND t.fraud_score > 50
GROUP BY c.region, a.account_type
ORDER BY tx_count DESC, flagged_count DESC;