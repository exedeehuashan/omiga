EXPLAIN (ANALYZE, BUFFERS, VERBOSE)
SELECT
    transaction_id,
    customer_id,
    account_id,
    merchant_id,
    amount,
    fraud_score,
    is_flagged,
    status,
    transaction_time
FROM fraud.transactions
WHERE amount > 10000
  AND fraud_score >= 60
ORDER BY amount DESC
LIMIT 100;