EXPLAIN (ANALYZE, BUFFERS, VERBOSE)
SELECT
    t.transaction_id,
    t.customer_id,
    t.account_id,
    a.account_type,
    a.status AS account_status,
    t.amount,
    t.fraud_score,
    t.transaction_time
FROM fraud.transactions t
JOIN fraud.accounts a
  ON t.customer_id = a.customer_id
 AND t.account_id = a.account_id
WHERE t.fraud_score > 75
  AND t.transaction_time >= NOW() - INTERVAL '30 days'
ORDER BY t.fraud_score DESC, t.transaction_time DESC
LIMIT 200;