EXPLAIN (ANALYZE, BUFFERS, VERBOSE)
SELECT
    date_trunc('day', transaction_time) AS tx_day,
    COUNT(*) AS total_tx,
    COUNT(*) FILTER (WHERE is_flagged = TRUE) AS flagged_tx,
    AVG(amount) AS avg_amount,
    AVG(fraud_score) AS avg_score,
    SUM(amount) AS total_amount
FROM fraud.transactions
GROUP BY date_trunc('day', transaction_time)
ORDER BY tx_day DESC;