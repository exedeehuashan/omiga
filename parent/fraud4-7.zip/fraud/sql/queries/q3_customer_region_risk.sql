EXPLAIN (ANALYZE, BUFFERS, VERBOSE)
SELECT
    c.region,
    c.risk_level,
    COUNT(*) AS flagged_tx_count,
    AVG(t.fraud_score) AS avg_score,
    SUM(t.amount) AS total_amount
FROM fraud.transactions t
JOIN fraud.customers c
  ON t.customer_id = c.customer_id
WHERE t.is_flagged = TRUE
GROUP BY c.region, c.risk_level
ORDER BY flagged_tx_count DESC, avg_score DESC;