EXPLAIN (ANALYZE, BUFFERS, VERBOSE)
SELECT
    transaction_id,
    customer_id,
    account_id,
    amount,
    fraud_score,
    transaction_time,
    location,
    channel,
    status
FROM fraud.transactions
WHERE transaction_time >= NOW() - INTERVAL '7 days'
  AND fraud_score >= 80
ORDER BY transaction_time DESC
LIMIT 100;