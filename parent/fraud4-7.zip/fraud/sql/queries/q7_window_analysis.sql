EXPLAIN (ANALYZE, BUFFERS, VERBOSE)
SELECT
    customer_id,
    account_id,
    transaction_time,
    amount,
    fraud_score,
    SUM(amount) OVER (
        PARTITION BY customer_id
        ORDER BY transaction_time
        ROWS BETWEEN 9 PRECEDING AND CURRENT ROW
    ) AS rolling_10_tx_amount,
    AVG(fraud_score) OVER (
        PARTITION BY customer_id
        ORDER BY transaction_time
        ROWS BETWEEN 9 PRECEDING AND CURRENT ROW
    ) AS rolling_10_avg_score
FROM fraud.transactions
WHERE transaction_time >= NOW() - INTERVAL '30 days'
LIMIT 1000;