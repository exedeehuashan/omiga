EXPLAIN (ANALYZE, BUFFERS, VERBOSE)
SELECT
    customer_id,
    account_id,
    COUNT(*) AS tx_count,
    SUM(amount) AS total_amount,
    AVG(fraud_score) AS avg_fraud_score
FROM fraud.transactions
WHERE transaction_time >= NOW() - INTERVAL '24 hours'
GROUP BY customer_id, account_id
HAVING COUNT(*) > 5
ORDER BY tx_count DESC, total_amount DESC
LIMIT 100;